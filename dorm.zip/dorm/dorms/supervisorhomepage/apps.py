from django.apps import AppConfig


class SupervisorhomepageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'supervisorhomepage'
