from django.db import models

class Dorm(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name

    def get_empty_rooms(self):
        occupied_room_numbers = self.reservations.filter(is_active=True).values_list('room__number', flat=True)
        return self.rooms.exclude(number__in=occupied_room_numbers)
