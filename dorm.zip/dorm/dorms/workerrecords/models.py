from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class DormWorker(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    profile_picture = models.ImageField(upload_to='dorm_worker_profile_pictures', null=True, blank=True)
    about_me = models.TextField(null=True, blank=True)
    dorm_building = models.CharField(max_length=50, null=True, blank=True)
    position = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return f"{self.user}'s Dorm Worker Profile"


class DormWorkerAttendance(models.Model):
    worker = models.ForeignKey(DormWorker, on_delete=models.CASCADE)
    date = models.DateField()
    time_in = models.DateTimeField()
    time_out = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.worker.user} Attendance for {self.date}"
