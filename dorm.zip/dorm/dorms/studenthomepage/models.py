from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class StudentHomePage(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    profile_picture = models.ImageField(upload_to='student_profile_pictures', null=True, blank=True)
    about_me = models.TextField(null=True, blank=True)
    dorm_building = models.CharField(max_length=50, null=True, blank=True)
    dorm_room_number = models.CharField(max_length=10, null=True, blank=True)

    def __str__(self):
        return f"{self.user}'s Student Home Page"
