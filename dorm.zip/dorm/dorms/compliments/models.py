from django.db import models
from django.contrib.auth.models import User

class Compliment(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_compliments')
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_compliments')
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.sender} complimented {self.recipient} on {self.timestamp}'
