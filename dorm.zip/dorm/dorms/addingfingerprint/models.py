from django.db import models

class Dorm(models.Model):
    name = models.CharField(max_length=50)
    address = models.CharField(max_length=100)
    fingerprint_count = models.IntegerField(default=0)
    max_fingerprint_count = models.IntegerField(default=100)

    def add_fingerprint(self):
        if self.fingerprint_count < self.max_fingerprint_count:
            self.fingerprint_count += 1
            self.save()
        else:
            raise ValueError('Maximum fingerprint count reached')
