from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class RoomChangeRequest(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    current_room_number = models.CharField(max_length=10)
    requested_room_number = models.CharField(max_length=10)
    reason_for_change = models.TextField()
    is_approved = models.BooleanField(default=False)
    date_requested = models.DateTimeField(auto_now_add=True)
    date_approved = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.user}'s Room Change Request"
