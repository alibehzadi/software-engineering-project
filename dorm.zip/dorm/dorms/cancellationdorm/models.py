from django.db import models

class DormReservation(models.Model):
    dorm = models.ForeignKey('Dorm', on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    cancelled = models.BooleanField(default=False)

    def cancel_reservation(self):
        if not self.cancelled:
            self.cancelled = True
            self.save()
        else:
            raise ValueError('Reservation has already been cancelled')
