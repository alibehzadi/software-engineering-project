from django.apps import AppConfig


class RoozforooshConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'roozforoosh'
