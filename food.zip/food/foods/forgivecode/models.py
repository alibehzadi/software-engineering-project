import random

from django.db import models

class RandomCode(models.Model):
    code = models.CharField(max_length=6, unique=True)

    @classmethod
    def generate(cls):
        code = ''.join(random.choices('0123456789', k=6))
        return cls.objects.create(code=code)
