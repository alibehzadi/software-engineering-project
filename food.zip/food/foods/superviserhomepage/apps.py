from django.apps import AppConfig


class SuperviserhomepageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'superviserhomepage'
