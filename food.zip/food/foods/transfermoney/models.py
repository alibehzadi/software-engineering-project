from django.db import models
from django.contrib.auth import get_user_model

class Wallet(models.Model):
    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    balance = models.DecimalField(max_digits=10, decimal_places=2)

class Transaction(models.Model):
    sender = models.ForeignKey(Wallet, on_delete=models.CASCADE, related_name='sender_wallet')
    receiver = models.ForeignKey(Wallet, on_delete=models.CASCADE, related_name='receiver_wallet')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        self.sender.balance -= self.amount
        self.receiver.balance += self.amount
        self.sender.save()
        self.receiver.save()
        super().save(*args, **kwargs)
