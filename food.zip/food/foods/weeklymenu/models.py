from django.db import models

class Food(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

class Menu(models.Model):
    DAYS_OF_WEEK = [
        ('Monday', 'Monday'),
        ('Tuesday', 'Tuesday'),
        ('Wednesday', 'Wednesday'),
        ('Thursday', 'Thursday'),
        ('Friday', 'Friday'),
        ('Saturday', 'Saturday'),
        ('Sunday', 'Sunday')
    ]

    DAY_TIME_CHOICES = [
        ('lunch', 'Lunch'),
        ('dinner', 'Dinner')
    ]

    day_of_week = models.CharField(max_length=9, choices=DAYS_OF_WEEK)
    day_time = models.CharField(max_length=6, choices=DAY_TIME_CHOICES)
    food = models.ManyToManyField(Food)

    def __str__(self):
        return f"{self.get_day_of_week_display()} {self.get_day_time_display()}"
